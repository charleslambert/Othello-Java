package javagame;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BoardTest {

	private Board boards;
	private Window game;

	@Before
	public void setUp() throws Exception {
		game = new Window("bob");
		boards = game.board;
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testDirection_array() {
		// I would have tested the length of the direction array
		// to make sure it was actually being created
	}

	@Test
	public void testAll_direction_arrays() {
		//I would have checked the length of all direction arrays which should be 8
	}

	@Test
	public void testCount_pieces() {
		// I would have tested the count so that it counted the correct number
		// number of pieces for each player
	}

	@Test
	public void testCount() {
		// I would have checked to see if it was counting pieces
	}

	@Test
	public void testIs_valid_move() {
		// I would check to make sure that move validation worked
	}

	@Test
	public void testPossible_move() {
		// I would check to see if it could tell if there were possible moves
	}

	@Test
	public void testPossible_moves() {
		// I would have tested to see if a player had any possible moves
	}

	@Test
	public void testNo_moves_left() {
		// I would have tested to see if either player had any moves
	}

	//I was not able to test most of the methods because they are based on state
}

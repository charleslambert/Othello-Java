package javagame;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class SpaceTest {

	public Window window;
	private Space space;
	
	@Before
	public void setUp() throws Exception {
		window = new Window("bob");
		space = Window.board.grid[0][0];
	}

	@After
	public void tearDown() throws Exception {
	}

	//I wasn't able to do any test here because I could not figure out the error
}
